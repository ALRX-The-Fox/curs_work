using authorization.Encryption;
using authorization.Entities;
using MongoDB.Bson;
using MongoDB.Driver;

namespace authorization.Repositories
{
    public class MongoDbStudentsRepository : IStudentsRepository
    {
        private const string DbName = "University";
        private const string ClName = "Students";
        private readonly IMongoCollection<Student> _studentsCollection;
        private readonly FilterDefinitionBuilder<Student> _filterDefinitionBuilder = Builders<Student>.Filter;
        
        public MongoDbStudentsRepository(IMongoClient mongoClient)
        {
            IMongoDatabase db = mongoClient.GetDatabase(DbName);
            _studentsCollection = db.GetCollection<Student>(ClName);
        }
        
        public async Task<IEnumerable<Student>> GetStudentsAsync()
        {
            return await _studentsCollection.Find(new BsonDocument()).ToListAsync();
        }

        public async Task<Student> GetStudentAsync(Guid id)
        {
            var filter = _filterDefinitionBuilder.Eq(student => student.Id, id);
            return await _studentsCollection.Find(filter).SingleOrDefaultAsync();        
        }

        public async Task AddStudentAsync(Student student)
        {
            await _studentsCollection.InsertOneAsync(student);
        }

        public async Task UpdateStudentAsync(Student student)
        {
            var filter = _filterDefinitionBuilder.Eq(existingItem => existingItem.Id, student.Id);
            await _studentsCollection.ReplaceOneAsync(filter, student);
        }

        public async Task DeleteStudentAsync(Guid id)
        {
            var filter = _filterDefinitionBuilder.Eq(student => student.Id, id);
            await _studentsCollection.DeleteOneAsync(filter);
        }
    }
}