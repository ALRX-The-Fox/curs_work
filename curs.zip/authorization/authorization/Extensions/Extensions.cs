using authorization.Dtos;
using authorization.Entities;

namespace authorization.Extensions
{
    public static class Extensions
    {
        public static StudentDto AsDto(this Student student)
        {
            return new StudentDto()
            {
                Id = student.Id,
                Login = student.Login,
                Password = student.Password,
                CreatedDate = student.CreatedDate
            };
        }
    }
}