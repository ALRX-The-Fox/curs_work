using authorization.Dtos;
using authorization.Encryption;
using authorization.Entities;
using authorization.Extensions;
using authorization.Repositories;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace authorization.Controllers
{
    [EnableCors("MyPolicy")]
    [ApiController]
    [Route("students")]
    public class StudentsController : ControllerBase
    {
        private readonly IStudentsRepository _repository;
        private readonly ILogger<StudentsController> _logger;

        public StudentsController(IStudentsRepository repository, ILogger<StudentsController> logger)
        {
            _repository = repository;
            _logger = logger;
        }

        // GET /students
        [HttpGet]
        public async Task<IEnumerable<StudentDto>> GetStudentsAsync()
        {
            var students = (await _repository.GetStudentsAsync()).
                Select(student => student.AsDto());

            return students;
        }

        // GET /students/id
        [HttpGet("{id}")]
        [ActionName(nameof(GetStudentAsync))]
        public async Task<ActionResult<StudentDto>> GetStudentAsync(Guid id)
        {
            var student = await _repository.GetStudentAsync(id);

            if (student is null)
            {
                return NotFound();
            }

            return student.AsDto();
        }
        
        // POST /students
        [HttpPost]
        public async Task<ActionResult<StudentDto>> AddStudentAsync(AddStudentDto studentDto)
        {
            DataEncrypt dataEncrypt = new DataEncrypt();
            studentDto = dataEncrypt.EncryptOne(studentDto);
            Student student = new()
            {
                Id = Guid.NewGuid(),
                Login = studentDto.Login,
                Password = studentDto.Password,
                CreatedDate = DateTimeOffset.UtcNow
            };

            await _repository.AddStudentAsync(student);
            return CreatedAtAction(nameof(GetStudentAsync), new { id = student.Id }, student.AsDto());
        }
        
        // PUT /students/{id}
        [HttpPut("{id}")]
        public async Task<ActionResult> UpdateStudentAsync(Guid id, UpdateStudentDto studentDto)
        {
            var exStudent = await _repository.GetStudentAsync(id);
            
            if (exStudent is null)
            {
                return NotFound();
            }

            Student updatedStudent = exStudent with
            {
                Login = studentDto.Login,
                Password = studentDto.Password,
            };
            
            await _repository.UpdateStudentAsync(updatedStudent);

            return NoContent();
        }

        // DELETE /items/{id}
        [HttpDelete]
        public async Task<ActionResult> DeleteStudentAsync(Guid id)
        {
            var exStudent = await _repository.GetStudentAsync(id);
            
            if (exStudent is null)
            {
                return NotFound();
            }
            
            await _repository.DeleteStudentAsync(id);

            return NoContent();
        }
    }
}