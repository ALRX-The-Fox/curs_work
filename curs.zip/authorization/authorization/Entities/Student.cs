namespace authorization.Entities
{
    public record Student
    {
        public Guid Id { get; init; }
        public string Login { get; init; }
        public string Password { get; init; }
        public DateTimeOffset CreatedDate { get; set; }
    }
}