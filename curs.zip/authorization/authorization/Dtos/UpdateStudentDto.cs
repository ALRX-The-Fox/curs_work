using System.ComponentModel.DataAnnotations;

namespace authorization.Dtos
{
    public class UpdateStudentDto
    {
        [Required]
        public string Login { get; init; }
        
        [Required]
        public string Password { get; init; }
    }
}