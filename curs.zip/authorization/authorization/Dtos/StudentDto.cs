namespace authorization.Dtos
{
    public class StudentDto
    {
        public Guid Id { get; init; }
        public string Login { get; init; }
        public string Password { get; init; }
        public DateTimeOffset CreatedDate { get; set; }
    }
}