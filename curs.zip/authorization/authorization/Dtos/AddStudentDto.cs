using System.ComponentModel.DataAnnotations;

namespace authorization.Dtos
{
    public record AddStudentDto
    {
        [Required]
        public string Login { get; init; }
        
        [Required]
        public string Password { get; init; }
    }
}