﻿using System.Security.Cryptography;
using System.Text;
using authorization.Dtos;
using authorization.Entities;

namespace authorization.Encryption;

public class DataEncrypt
{
    private static byte[] key = new byte[8] {1, 2, 3, 4, 5, 6, 7, 8};
    private static byte[] iv = new byte[8] {1, 2, 3, 4, 5, 6, 7, 8};

    public AddStudentDto EncryptOne(AddStudentDto student)
    {
        try
        {
            DES DESalg = DES.Create();
            return new AddStudentDto()
            {
                //DES
                Login = EncryptTextToMemory(student.Login, DESalg.Key, DESalg.IV),
                //Simple Encryption
                Password = Crypt(student.Password)
            };
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }

        return student;
    }
    
    public static string EncryptTextToMemory(string Data,  byte[] Key, byte[] IV)
    {
        try
        {
            MemoryStream mStream = new MemoryStream();
            DES DESalg = DES.Create();
            
            CryptoStream cStream = new CryptoStream(mStream,
                DESalg.CreateEncryptor(Key, IV),
                CryptoStreamMode.Write);
            byte[] toEncrypt = new ASCIIEncoding().GetBytes(Data);
            cStream.Write(toEncrypt, 0, toEncrypt.Length);
            cStream.FlushFinalBlock();
            byte[] ret = mStream.ToArray();
            cStream.Close();
            mStream.Close();
            return Encoding.Default.GetString(ret);
        }
        catch(CryptographicException e)
        {
            Console.WriteLine("A Cryptographic error occurred: {0}", e.Message);
            return null;
        }
    }
    
        public string Crypt(string text)
        {
            SymmetricAlgorithm algorithm = DES.Create();
            ICryptoTransform transform = algorithm.CreateEncryptor(key, iv);
            byte[] inputbuffer = Encoding.Unicode.GetBytes(text);
            byte[] outputBuffer = transform.TransformFinalBlock(inputbuffer, 0, inputbuffer.Length);
            return Convert.ToBase64String(outputBuffer);
        }
    
        public string Decrypt(string text)
        {
            SymmetricAlgorithm algorithm = DES.Create();
            ICryptoTransform transform = algorithm.CreateDecryptor(key, iv);
            byte[] inputbuffer = Convert.FromBase64String(text);
            byte[] outputBuffer = transform.TransformFinalBlock(inputbuffer, 0, inputbuffer.Length);
            return Encoding.Unicode.GetString(outputBuffer);
        }
    
}