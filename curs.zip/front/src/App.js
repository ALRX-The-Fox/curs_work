import './styles/App.css';
import Data from "./components/Data";

function App() {
  return (
    <div className="App">
        <Data />
    </div>
  );
}

export default App;
