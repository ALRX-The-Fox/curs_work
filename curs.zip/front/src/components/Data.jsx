import React, {useState} from 'react';
import '../styles/Data.css'
import './Form.css'
const Data = () => {
    const [email, setEmail] = React.useState('');
    const [password, setPassword] = React.useState('');

    var newTask = {
        login: email,
        password: password
    }

    const handleEmailChange = event => {
        setEmail(event.target.value)
    };
    const handlePasswordChange = event => {
        setPassword(event.target.value)
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const url = 'https://localhost:7165/students'
        const requestOptions = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(newTask)
        };
        fetch(url, requestOptions)
            .then(response => console.log('Submitted successfully'))
            .catch(error => console.log('Form submit error', error))
    };

    return (
        <div className='form'>
            <h1 className="title"> 👋 Konichiwa! </h1>
            <form onSubmit={handleSubmit}>
                <div className='input'>
                    <input className="input-container ic1"
                           type="user"
                           name="user"
                           placeholder="Enter Email"
                           onChange={handleEmailChange}
                           value={email}
                    />
                </div>
                <div className='input'>
                    <input type="description"
                           name="description"
                           placeholder="Enter Password"
                           onChange={handlePasswordChange}
                           value={password}/>
                </div>
                <div className='button'>
                    <button className="submit" type="submit" onClick={handleSubmit}> Submit </button>
                </div>
            </form>
        </div>
    );
};

export default Data;